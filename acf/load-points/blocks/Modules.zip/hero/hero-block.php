<?php

/**
 * Testimonial Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

// Create id attribute allowing for custom "anchor" value.
$id = 'hero-' . $block['id'];
if( !empty($block['anchor']) ) {
    $id = $block['anchor'];
}

// Create class attribute allowing for custom "className" and "align" values.
$className = 'hero';
if( !empty($block['className']) ) {
    $className .= ' ' . $block['className'];
}
if( !empty($block['align']) ) {
    $className .= ' align' . $block['align'];
}


?>
<div id="<?php echo esc_attr($id); ?>" class="<?php echo esc_attr($className); ?>">
    <h1><?php the_field('main_title'); ?></h1>
    <p><?php the_field('subtitle'); ?></p>
    <div><?php the_field('content'); ?></div>
    
    <div class="hero">
        <?php if( have_rows('hero_slides') ): while ( have_rows('hero_slides') ) : the_row(); ?>
            <?php $variable = get_sub_field('background'); ?>
            <div class="hero_background">
                <?php echo wp_get_attachment_image( $variable, 'full' ); ?>    
            </div>
            <div class="hero_content">
                <?php the_sub_field('title'); ?>
                <?php the_sub_field('subtitle'); ?>           
            </div>
        <?php endwhile; endif; ?>
    </div>

        
    <style type="text/css">
        #<?php echo $id; ?> {
            background: <?php echo $background_color; ?>;
            color: <?php echo $text_color; ?>;
        }
    </style>
</div>